/**
 * CareerSphere AI — HR Recruiter & Hiring Manager Workspace
 * Phase 1 Foundation: Pipeline metrics, active job listings, and requisition builder.
 */
import React, { useState } from 'react';
import { BenchmarkJob } from '../../types';
import { PlusCircle, Users, CheckCircle2, Search, Briefcase, Filter, ArrowUpRight } from 'lucide-react';

interface RecruiterDashboardProps {
  jobs: BenchmarkJob[];
  onAddJob: (newJob: BenchmarkJob) => void;
}

export const RecruiterDashboard: React.FC<RecruiterDashboardProps> = ({
  jobs,
  onAddJob,
}) => {
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDepartment, setNewDepartment] = useState('Engineering');
  const [newLocation, setNewLocation] = useState('Remote (US)');
  const [newSalary, setNewSalary] = useState('$150,000 - $190,000');
  const [newSkills, setNewSkills] = useState('Python, Django, PostgreSQL, Docker');

  const applicants = [
    {
      id: 'cand_01',
      name: 'Elena Rostova',
      role: 'Senior AI Systems Architect',
      experienceYears: 7.5,
      matchScore: 94,
      skills: ['Python', 'PyTorch', 'Vector DBs', 'Kubernetes'],
      status: 'Technical Screen',
      appliedDaysAgo: 1,
    },
    {
      id: 'cand_02',
      name: 'Marcus Vance',
      role: 'Full-Stack Software Engineer',
      experienceYears: 5.0,
      matchScore: 89,
      skills: ['Django REST', 'React 19', 'TypeScript', 'Docker'],
      status: 'Resume Reviewed',
      appliedDaysAgo: 2,
    },
    {
      id: 'cand_03',
      name: 'Aisha Al-Mansoor',
      role: 'Machine Learning Operations Lead',
      experienceYears: 6.2,
      matchScore: 84,
      skills: ['AWS SageMaker', 'MLflow', 'Terraform', 'Python'],
      status: 'Initial Outreach',
      appliedDaysAgo: 3,
    },
    {
      id: 'cand_04',
      name: 'David Kim',
      role: 'Senior AI Systems Architect',
      experienceYears: 8.0,
      matchScore: 82,
      skills: ['C++', 'Python', 'CUDA', 'Distributed Storage'],
      status: 'Screen Scheduled',
      appliedDaysAgo: 4,
    },
  ];

  const handleCreateJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const jobPayload: BenchmarkJob = {
      id: `job_${Date.now()}`,
      title: newTitle.trim(),
      company_name: 'Synthetix Dynamics',
      location: newLocation,
      workplace_type: 'Remote',
      employment_type: 'Full-time',
      salary_range: newSalary,
      skills_required: newSkills.split(',').map((s) => s.trim()).filter(Boolean),
      match_score_demo: 90,
      applicants_count: 0,
      posted_days_ago: 0,
      description: `Targeting an experienced ${newTitle} to expand our engineering organization.`,
    };

    onAddJob(jobPayload);
    setCreateModalOpen(false);
    setNewTitle('');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-100 text-left">
      
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
            Recruiter Workspace · Talent Acquisition Console
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Synthetix Dynamics · Hiring Pipeline
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl">
            Managing <span className="text-white font-medium">{jobs.length} Active Requisitions</span> with automated AI candidate scoring and talent radar diagnostics.
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-md shadow-indigo-600/30 transition-colors shrink-0 cursor-pointer"
        >
          <PlusCircle className="h-4 w-4" />
          <span>Post New Job Requisition</span>
        </button>
      </div>

      {/* Metric KPI Strip (High-density SaaS layout) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">Active Requisitions</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">{jobs.length}</div>
          <div className="text-[11px] text-emerald-400">All positions published</div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">Total Inbound Candidates</div>
          <div className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">124</div>
          <div className="text-[11px] text-slate-400">+18 this week</div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">AI Screening Qualification Rate</div>
          <div className="text-2xl font-bold font-mono text-indigo-400 tabular-nums">68%</div>
          <div className="text-[11px] text-slate-400">Threshold: &gt;75% match</div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">Avg Time-to-Screen</div>
          <div className="text-2xl font-bold font-mono text-slate-200 tabular-nums">2.4 days</div>
          <div className="text-[11px] text-slate-400">Automated pre-filtering</div>
        </div>
      </div>

      {/* Candidate Pipeline Funnel */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-sm font-semibold text-white">Pipeline Stage Funnel Overview</h2>
          <span className="text-xs font-mono text-slate-400">Phase 1 Workflow Schema</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-1">
          <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">1. Sourced & Applied</span>
              <span className="font-mono text-white tabular-nums font-bold">124</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-slate-400 h-1.5 rounded-full w-full" />
            </div>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">2. AI Pre-Screened</span>
              <span className="font-mono text-cyan-400 tabular-nums font-bold">84</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-cyan-500 h-1.5 rounded-full w-[68%]" />
            </div>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">3. Technical Interview</span>
              <span className="font-mono text-indigo-400 tabular-nums font-bold">29</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-indigo-500 h-1.5 rounded-full w-[24%]" />
            </div>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">4. Offer Extended</span>
              <span className="font-mono text-emerald-400 tabular-nums font-bold">6</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-1.5 rounded-full w-[5%]" />
            </div>
          </div>
        </div>
      </div>

      {/* Active Job Requisitions Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white">Active Job Listings</h2>
          <span className="text-xs text-slate-400 font-mono">{jobs.length} Requisitions Active</span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-medium">
              <tr>
                <th className="py-3 px-4">Position Title</th>
                <th className="py-3 px-4">Location & Type</th>
                <th className="py-3 px-4">Compensation Band</th>
                <th className="py-3 px-4 text-center">Applicants</th>
                <th className="py-3 px-4 text-right">Requisition Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {jobs.map((job) => (
                <tr key={job.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-white">{job.title}</div>
                    <div className="text-[11px] text-slate-400">{job.skills_required.slice(0, 3).join(' · ')}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div>{job.location}</div>
                    <div className="text-[11px] text-slate-400">{job.workplace_type} · {job.employment_type}</div>
                  </td>
                  <td className="py-3.5 px-4 font-mono tabular-nums">{job.salary_range}</td>
                  <td className="py-3.5 px-4 text-center font-mono tabular-nums font-medium text-cyan-400">
                    {job.applicants_count}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <span className="inline-block px-2.5 py-1 rounded text-[11px] font-medium bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                      Active
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent High-Scoring Applicants */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white">Recent Top-Match Applicants</h2>
          <span className="text-xs text-slate-400 font-mono">Ranked by AI Match Diagnostics</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {applicants.map((cand) => (
            <div
              key={cand.id}
              className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-semibold text-white text-sm">{cand.name}</div>
                    <div className="text-xs text-slate-400">
                      Targeting: {cand.role} · {cand.experienceYears} yrs experience
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-sm font-bold text-emerald-400 tabular-nums">
                      {cand.matchScore}%
                    </div>
                    <div className="text-[10px] text-slate-500">Match Score</div>
                  </div>
                </div>

                <div className="text-xs text-slate-300">
                  <span className="text-slate-500">Skills: </span>
                  <span>{cand.skills.join(' · ')}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono text-[11px]">Applied {cand.appliedDaysAgo}d ago</span>
                <span className="px-2.5 py-1 rounded text-[11px] font-medium bg-slate-800 text-indigo-300 border border-slate-700/80">
                  {cand.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create Requisition Modal */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <form
            onSubmit={handleCreateJob}
            className="relative w-full max-w-lg rounded-xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-2xl"
          >
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">Create New Job Requisition</h3>
              <p className="text-xs text-slate-400">
                Phase 1 JobListing model schema will validate requirements and salary bounds.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-medium">Position Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Senior Machine Learning Engineer"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Department</label>
                  <input
                    type="text"
                    value={newDepartment}
                    onChange={(e) => setNewDepartment(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Location & Work Style</label>
                  <input
                    type="text"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Compensation Range</label>
                <input
                  type="text"
                  value={newSalary}
                  onChange={(e) => setNewSalary(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Target Skill Tags (comma-separated)</label>
                <input
                  type="text"
                  value={newSkills}
                  onChange={(e) => setNewSkills(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCreateModalOpen(false)}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm cursor-pointer"
              >
                Publish Requisition
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
