/**
 * CareerSphere AI — Candidate & Student Workspace
 * Phase 1 Foundation: Clearly identified demo data with active resume upload validation.
 */
import React, { useState } from 'react';
import { BenchmarkJob, CandidateResume, ApplicationActivity } from '../../types';
import { Upload, Sparkles, FileText, CheckCircle2, ArrowUpRight, Search, AlertCircle, Briefcase, ExternalLink } from 'lucide-react';

interface CandidateDashboardProps {
  jobs: BenchmarkJob[];
  onOpenUploadModal: () => void;
  resumes: CandidateResume[];
}

export const CandidateDashboard: React.FC<CandidateDashboardProps> = ({
  jobs,
  onOpenUploadModal,
  resumes,
}) => {
  const [filter, setFilter] = useState<'all' | 'remote' | 'engineering'>('all');
  const [selectedJob, setSelectedJob] = useState<BenchmarkJob | null>(null);
  const [applicationModalOpen, setApplicationModalOpen] = useState(false);
  const [appliedJobIds, setAppliedJobIds] = useState<string[]>(['job_02']);
  const [consentGranted, setConsentGranted] = useState(false);

  const filteredJobs = jobs.filter((job) => {
    if (filter === 'remote') return job.workplace_type === 'Remote';
    if (filter === 'engineering') return job.title.toLowerCase().includes('engineer') || job.title.toLowerCase().includes('architect');
    return true;
  });

  const recentApplications: ApplicationActivity[] = [
    {
      id: 'app_01',
      jobTitle: 'Full-Stack Software Engineer (Python & React)',
      companyName: 'Horizon Cloud Labs',
      appliedDate: '2026-10-08',
      status: 'Interview Scheduled',
      matchScore: 88,
      portal: 'Greenhouse Partner API',
    },
    {
      id: 'app_02',
      jobTitle: 'Distributed Systems Core Engineer',
      companyName: 'Starlight Scale',
      appliedDate: '2026-10-04',
      status: 'Under Review',
      matchScore: 82,
      portal: 'Lever Postings API',
    },
    {
      id: 'app_03',
      jobTitle: 'AI Platform Specialist',
      companyName: 'Apex Dataworks',
      appliedDate: '2026-09-29',
      status: 'Submitted',
      matchScore: 79,
      portal: 'Official Manual Portal Handoff',
    },
  ];

  const handleApplyClick = (job: BenchmarkJob) => {
    setSelectedJob(job);
    setConsentGranted(false);
    setApplicationModalOpen(true);
  };

  const handleConfirmApplication = () => {
    if (!selectedJob) return;
    setAppliedJobIds((prev) => [...prev, selectedJob.id]);
    setApplicationModalOpen(false);
  };

  const primaryResume = resumes[0] || {
    id: 'res_default',
    title: 'Senior_Fullstack_Engineer_Resume_2026.pdf',
    fileName: 'Senior_Fullstack_Engineer_Resume_2026.pdf',
    fileSizeBytes: 245000,
    fileFormat: 'PDF',
    uploadedAt: 'Oct 09, 2026',
    isPrimary: true,
    parsingStatus: 'parsed',
    atsScoreDemo: 88,
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-100">
      
      {/* Welcome Banner */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 text-left">
          <div className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
            Candidate Workspace · Phase 1 Initial Implementation
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Welcome back, Alex Chen
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl">
            Target Role: <span className="text-slate-100 font-medium">Senior AI & Full-Stack Systems Engineer</span>. Your profile is 75% complete with 1 active resume on file.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenUploadModal}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-md shadow-indigo-600/30 transition-colors cursor-pointer"
          >
            <Upload className="h-4 w-4" />
            <span>Upload New Resume</span>
          </button>
        </div>
      </div>

      {/* Grid: Profile Readiness & AI Resume Diagnostics Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left: Active Resume & Profile Completeness (4 cols) */}
        <div className="lg:col-span-4 rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Primary Document</span>
              <span className="text-[11px] font-mono text-emerald-400">Validated 10MB</span>
            </div>

            <div className="p-4 rounded-lg border border-slate-800 bg-slate-950/60 space-y-2">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                  <FileText className="h-5 w-5" />
                </div>
                <div className="overflow-hidden">
                  <div className="text-sm font-semibold text-white truncate">{primaryResume.title}</div>
                  <div className="text-xs text-slate-400">
                    {primaryResume.fileFormat} · {(primaryResume.fileSizeBytes / 1024).toFixed(0)} KB · Uploaded {primaryResume.uploadedAt}
                  </div>
                </div>
              </div>
            </div>

            {/* Profile Completion Indicator */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Profile Readiness</span>
                <span className="font-mono text-slate-200 tabular-nums">75% Complete</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div className="bg-gradient-to-r from-indigo-500 to-cyan-400 h-2 rounded-full w-[75%]" />
              </div>
              <div className="text-[11px] text-slate-400">
                Tip: Add your GitHub profile URL and 2 more specialized skill keywords to reach 100%.
              </div>
            </div>
          </div>

          <button
            onClick={onOpenUploadModal}
            className="w-full py-2 text-xs font-medium text-slate-300 hover:text-white border border-slate-700 bg-slate-800/60 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            Manage Resume Documents ({resumes.length})
          </button>
        </div>

        {/* Right: AI Resume Copilot Diagnostics Breakdown (8 cols) */}
        <div className="lg:col-span-8 rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-indigo-400" />
              <h2 className="text-sm font-semibold text-white">AI Resume Diagnostics Preview</h2>
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              Demo Match Indicator: <span className="text-emerald-400 font-bold tabular-nums">88%</span> · Pending Phase 4 AI Engine
            </div>
          </div>

          {/* 3 Metric Breakdown Bars */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-1.5">
              <div className="text-xs text-slate-400">ATS Parsing Score</div>
              <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">88%</div>
              <div className="text-[11px] text-slate-500">Standard single-column format verified.</div>
            </div>
            <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-1.5">
              <div className="text-xs text-slate-400">Metric Quantification</div>
              <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums">76%</div>
              <div className="text-[11px] text-slate-500">Add percentages on latency improvements.</div>
            </div>
            <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-1.5">
              <div className="text-xs text-slate-400">Target Role Alignment</div>
              <div className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">91%</div>
              <div className="text-[11px] text-slate-500">High match with modern Python/TS stacks.</div>
            </div>
          </div>

          {/* Skill gaps and recommendations */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-1">
            <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-950/40 space-y-2">
              <span className="font-semibold text-slate-300">Identified Matching Competencies</span>
              <div className="text-slate-300 leading-relaxed">
                Python · Django REST · React 19 · TypeScript · PostgreSQL · Docker · REST APIs
              </div>
            </div>
            <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-950/40 space-y-2">
              <span className="font-semibold text-amber-300">Suggested Missing Competencies</span>
              <div className="text-slate-300 leading-relaxed">
                Vector Databases (Pinecone/Milvus) · Celery Task Tuning · Kubernetes Helm
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Job Listings Section */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-white">Recommended Opportunities</h2>
            <div className="text-xs text-slate-400">
              Curated positions matching your career preferences · Clearly identified demo data
            </div>
          </div>

          {/* Segmented Filter Controls */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg self-start">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                filter === 'all' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              All Roles ({jobs.length})
            </button>
            <button
              onClick={() => setFilter('remote')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                filter === 'remote' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Remote Only
            </button>
            <button
              onClick={() => setFilter('engineering')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                filter === 'engineering' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Engineering
            </button>
          </div>
        </div>

        {/* Job Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredJobs.map((job) => {
            const isApplied = appliedJobIds.includes(job.id);
            return (
              <div
                key={job.id}
                className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-4 flex flex-col justify-between hover:border-slate-700 transition-colors text-left"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-base font-semibold text-white leading-snug">{job.title}</h3>
                      <div className="text-xs text-slate-400 mt-0.5">
                        {job.company_name} · {job.location}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-sm font-mono font-bold text-emerald-400 tabular-nums">
                        {job.match_score_demo}%
                      </div>
                      <div className="text-[10px] text-slate-500">Demo Match</div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                    {job.description}
                  </p>

                  <div className="text-xs text-slate-400">
                    <span className="text-slate-500">Skills: </span>
                    <span>{job.skills_required.join(' · ')}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <div className="font-mono text-slate-200 tabular-nums">
                    {job.salary_range} · {job.employment_type}
                  </div>

                  {isApplied ? (
                    <span className="flex items-center gap-1 font-mono text-xs text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>Application Active</span>
                    </span>
                  ) : (
                    <button
                      onClick={() => handleApplyClick(job)}
                      className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors cursor-pointer"
                    >
                      Guided Apply
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Application Activity Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white">Recent Application Pipeline</h2>
          <span className="text-xs text-slate-400 font-mono">3 Active Submissions</span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-medium">
              <tr>
                <th className="py-3 px-4">Role & Company</th>
                <th className="py-3 px-4">Applied Date</th>
                <th className="py-3 px-4">Submission Route</th>
                <th className="py-3 px-4 text-right">Match Snapshot</th>
                <th className="py-3 px-4 text-right">Workflow Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {recentApplications.map((app) => (
                <tr key={app.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-white">{app.jobTitle}</div>
                    <div className="text-[11px] text-slate-400">{app.companyName}</div>
                  </td>
                  <td className="py-3.5 px-4 font-mono tabular-nums">{app.appliedDate}</td>
                  <td className="py-3.5 px-4 text-slate-400">{app.portal}</td>
                  <td className="py-3.5 px-4 text-right font-mono tabular-nums text-emerald-400 font-medium">
                    {app.matchScore}%
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <span className="inline-block px-2.5 py-1 rounded text-[11px] font-medium bg-slate-800 text-indigo-300 border border-slate-700/80">
                      {app.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Guided Application Modal */}
      {applicationModalOpen && selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-xl border border-slate-800 bg-slate-900 p-6 space-y-5 shadow-2xl text-left">
            <div className="space-y-1">
              <div className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
                Phase 1 Application Dispatch Preview
              </div>
              <h3 className="text-lg font-bold text-white">{selectedJob.title}</h3>
              <div className="text-xs text-slate-400">
                {selectedJob.company_name} · {selectedJob.location}
              </div>
            </div>

            <div className="p-4 rounded-lg border border-slate-800 bg-slate-950/70 space-y-2 text-xs">
              <div className="text-slate-300">
                <span className="font-medium text-white">Target Compensation:</span> {selectedJob.salary_range}
              </div>
              <div className="text-slate-300">
                <span className="font-medium text-white">Attached Resume:</span> {primaryResume.title}
              </div>
              <div className="text-slate-300">
                <span className="font-medium text-white">Submission Channel:</span> Verified Partner ATS Gateway
              </div>
            </div>

            {/* Zero-Bypass Consent Gate */}
            <div className="p-3.5 rounded-lg border border-indigo-900/40 bg-indigo-950/20 space-y-2 text-xs">
              <div className="flex items-center gap-2 text-indigo-300 font-semibold">
                <AlertCircle className="h-4 w-4" />
                <span>Mandatory Candidate Consent</span>
              </div>
              <label className="flex items-start gap-2.5 text-slate-300 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={consentGranted}
                  onChange={(e) => setConsentGranted(e.target.checked)}
                  className="mt-0.5 rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-indigo-500"
                />
                <span>
                  I explicitly authorize CareerSphere AI to submit my profile and validated resume to {selectedJob.company_name}.
                </span>
              </label>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setApplicationModalOpen(false)}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmApplication}
                disabled={!consentGranted}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-md transition-colors cursor-pointer"
              >
                Confirm Guided Submission
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
