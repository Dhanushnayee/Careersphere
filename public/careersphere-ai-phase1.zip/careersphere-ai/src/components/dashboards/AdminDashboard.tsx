/**
 * CareerSphere AI — System Administrator Hub
 * Phase 1 Foundation: Total users, moderation summaries, live audit stream, and security diagnostics.
 */
import React from 'react';
import { AuditRecord, PlatformHealth } from '../../types';
import { ShieldCheck, Activity, Users, AlertTriangle, Database, CheckCircle2, FileText, Cpu, Lock } from 'lucide-react';

interface AdminDashboardProps {
  auditLogs: AuditRecord[];
  health: PlatformHealth | null;
  onOpenHealth: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  auditLogs,
  health,
  onOpenHealth,
}) => {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-100 text-left">
      
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
            System Administrator Hub · Governance & Audit
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Platform Operations & Security Console
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl">
            Monitoring <span className="text-white font-medium">Phase 1 Infrastructure</span>, database connection health, 10MB private document enclaves, and immutable audit trails.
          </p>
        </div>

        <button
          onClick={onOpenHealth}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg shadow-md transition-colors shrink-0 cursor-pointer"
        >
          <Activity className="h-4 w-4 text-emerald-400" />
          <span>Inspect Deep Health Probes</span>
        </button>
      </div>

      {/* Aggregate System Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">Total User Accounts</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">1,420</div>
          <div className="text-[11px] text-slate-400 font-mono">1,180 Candidates · 240 Recruiters</div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">Total Active Job Requisitions</div>
          <div className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">85</div>
          <div className="text-[11px] text-slate-400 font-mono">Across 42 verified companies</div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">Application Submissions</div>
          <div className="text-2xl font-bold font-mono text-indigo-400 tabular-nums">3,890</div>
          <div className="text-[11px] text-slate-400 font-mono">100% consent confirmed</div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">Security Invariants</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">0 Breaches</div>
          <div className="text-[11px] text-emerald-400 font-mono">All policies compliant</div>
        </div>
      </div>

      {/* Security Policies & Moderation Diagnostics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
            <Lock className="h-4 w-4 text-indigo-400" />
            <span>Document Enclave Governance</span>
          </div>
          <div className="text-xs text-slate-400 space-y-1.5">
            <div>Limit: <span className="text-white font-mono">10 MB / document</span></div>
            <div>Allowed: <span className="text-white font-mono">PDF, DOCX, TXT</span></div>
            <div>Isolation: <span className="text-emerald-400">Candidate-Private</span></div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
            Enforced in apps.resumes.views
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
            <ShieldCheck className="h-4 w-4 text-cyan-400" />
            <span>Multi-Portal Automation Safety</span>
          </div>
          <div className="text-xs text-slate-400 space-y-1.5">
            <div>Gate: <span className="text-white">Candidate Positive Consent</span></div>
            <div>Submission: <span className="text-white">Partner APIs Only</span></div>
            <div>Bypass Prevention: <span className="text-emerald-400">Zero Bypass Policy</span></div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
            Enforced in apps.automation.models
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
            <Cpu className="h-4 w-4 text-emerald-400" />
            <span>System Health & Middleware</span>
          </div>
          <div className="text-xs text-slate-400 space-y-1.5">
            <div>Database: <span className="text-emerald-400 font-mono">PostgreSQL Active</span></div>
            <div>Broker: <span className="text-indigo-400 font-mono">Redis Standby</span></div>
            <div>CORS Whitelist: <span className="text-white font-mono">localhost:3000</span></div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
            Enforced in careersphere_ai.settings
          </div>
        </div>
      </div>

      {/* Immutable Security Audit Trail (Live from API) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white">Platform Audit Log Stream</h2>
            <div className="text-xs text-slate-400">
              Fetched from <span className="font-mono text-indigo-400">/api/v1/audit/logs/</span>
            </div>
          </div>
          <span className="text-xs text-slate-400 font-mono">{auditLogs.length} Records Verified</span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-medium">
              <tr>
                <th className="py-3 px-4">Action Event</th>
                <th className="py-3 px-4">Resource Target</th>
                <th className="py-3 px-4">Actor</th>
                <th className="py-3 px-4">IP Address</th>
                <th className="py-3 px-4">Event Summary</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-medium text-white">{log.action}</td>
                  <td className="py-3 px-4 text-indigo-300">{log.resource_type}</td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-400">{log.actor}</td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-400">{log.ip_address}</td>
                  <td className="py-3 px-4 text-slate-300 text-xs">{log.summary}</td>
                  <td className="py-3 px-4 text-right">
                    <span className="inline-block px-2.5 py-0.5 rounded text-[11px] font-mono font-medium bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
