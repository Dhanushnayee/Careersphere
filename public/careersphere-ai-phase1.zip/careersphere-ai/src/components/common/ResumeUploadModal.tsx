/**
 * CareerSphere AI — Resume Document Upload Modal
 * Enforces 10MB file size limit, format validation (PDF/DOCX/TXT), and API verification.
 */
import React, { useState, useRef } from 'react';
import { Modal } from './Modal';
import { apiClient } from '../../services/api';
import { CandidateResume } from '../../types';
import { Upload, FileText, CheckCircle2, AlertTriangle, Loader2 } from 'lucide-react';

interface ResumeUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (resume: CandidateResume) => void;
}

export const ResumeUploadModal: React.FC<ResumeUploadModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
}) => {
  const [title, setTitle] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      const maxBytes = 10 * 1024 * 1024; // 10 MB

      if (selected.size > maxBytes) {
        setError(`File exceeds the 10MB governance limit (${(selected.size / 1024 / 1024).toFixed(2)} MB). Please select a smaller file.`);
        setFile(null);
        return;
      }

      const ext = selected.name.split('.').pop()?.toLowerCase();
      if (!['pdf', 'docx', 'txt'].includes(ext || '')) {
        setError("Invalid document format. Only PDF, DOCX, and TXT files are accepted.");
        setFile(null);
        return;
      }

      setFile(selected);
      if (!title) {
        setTitle(selected.name.replace(/\.[^/.]+$/, ''));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError('Please select a resume file to upload.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const result = await apiClient.validateResumeUpload(title || file.name, file);
      setSuccess(true);

      const newResume: CandidateResume = {
        id: `res_${Date.now()}`,
        title: result.title || file.name,
        fileName: file.name,
        fileSizeBytes: file.size,
        fileFormat: file.name.split('.').pop()?.toUpperCase() || 'PDF',
        uploadedAt: 'Just now',
        isPrimary: false,
        parsingStatus: 'parsed',
        atsScoreDemo: 92,
      };

      setTimeout(() => {
        onUploadSuccess(newResume);
        onClose();
        setSuccess(false);
        setFile(null);
        setTitle('');
      }, 1200);
    } catch (err: any) {
      setError(err?.message || 'Failed to upload and validate resume document.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Upload Candidate Resume Document" maxWidth="max-w-lg">
      <form onSubmit={handleSubmit} className="space-y-4 text-left">
        
        {/* Governance banner */}
        <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/60 text-xs text-slate-400 space-y-1">
          <div className="text-slate-200 font-semibold">10MB Private Enclave Governance</div>
          <p>
            Your resume is protected in an isolated candidate partition. Supported formats: <span className="text-white font-mono">PDF, DOCX, TXT</span>.
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-lg border border-rose-900/40 bg-rose-950/20 text-xs text-rose-300 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="p-3 rounded-lg border border-emerald-900/40 bg-emerald-950/20 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
            <span>Document verified and saved to candidate profile!</span>
          </div>
        )}

        {/* Title Input */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">Document Label / Title</label>
          <input
            type="text"
            placeholder="e.g. Senior_AI_Systems_Engineer_2026.pdf"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* File Drag/Drop or Select Area */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">Select File (Max 10MB)</label>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".pdf,.docx,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain"
            className="hidden"
          />
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-800 hover:border-slate-700 bg-slate-950/40 rounded-xl p-6 text-center cursor-pointer transition-colors space-y-2"
          >
            <div className="h-10 w-10 mx-auto rounded-full bg-slate-900 flex items-center justify-center text-indigo-400">
              <Upload className="h-5 w-5" />
            </div>
            {file ? (
              <div className="space-y-1">
                <div className="text-xs font-medium text-white">{file.name}</div>
                <div className="text-[11px] text-slate-400 font-mono">
                  {(file.size / 1024).toFixed(1)} KB · Validated within limits
                </div>
              </div>
            ) : (
              <div className="space-y-1">
                <div className="text-xs font-medium text-slate-300">Click to browse file from your computer</div>
                <div className="text-[11px] text-slate-500">PDF, DOCX, or TXT up to 10MB</div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={!file || loading || success}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            {loading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            <span>{loading ? 'Validating...' : 'Upload & Verify'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
