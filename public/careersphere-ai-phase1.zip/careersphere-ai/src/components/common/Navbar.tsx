/**
 * CareerSphere AI — Top Navigation Bar
 * Follows strict Top Bar Contract: 3 zones separated by gap-8
 * Zone 1: Single text element wordmark
 * Zone 2: Concise single-line links
 * Zone 3: 1 primary action CTA
 */
import React, { useState } from 'react';
import { UserRole } from '../../types';
import { Menu, X, ShieldCheck, Sparkles, Layers } from 'lucide-react';

interface NavbarProps {
  currentView: 'landing' | 'candidate' | 'recruiter' | 'admin' | 'architecture';
  onNavigate: (view: 'landing' | 'candidate' | 'recruiter' | 'admin' | 'architecture') => void;
  onOpenHealth: () => void;
  backendConnected: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenHealth,
  backendConnected,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => {
            onNavigate('landing');
            setMobileMenuOpen(false);
          }}
          className="group flex items-center gap-2.5 text-left text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 transition-opacity hover:opacity-90 cursor-pointer"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-tr from-indigo-600 to-violet-500 text-white shadow-sm shadow-indigo-500/20">
            <Sparkles className="h-4 w-4" />
          </div>
          <span className="font-semibold text-slate-100">CareerSphere AI</span>
        </button>

        {/* Zone 2: 4-5 concise single-line text navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
          <button
            onClick={() => onNavigate('landing')}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer ${
              currentView === 'landing' ? 'text-indigo-400 font-semibold' : ''
            }`}
          >
            Platform
          </button>
          <button
            onClick={() => onNavigate('candidate')}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer ${
              currentView === 'candidate' ? 'text-indigo-400 font-semibold' : ''
            }`}
          >
            Candidate Workspace
          </button>
          <button
            onClick={() => onNavigate('recruiter')}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer ${
              currentView === 'recruiter' ? 'text-indigo-400 font-semibold' : ''
            }`}
          >
            Recruiter Workspace
          </button>
          <button
            onClick={() => onNavigate('admin')}
            className={`whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer ${
              currentView === 'admin' ? 'text-indigo-400 font-semibold' : ''
            }`}
          >
            Admin Hub
          </button>
          <button
            onClick={() => onNavigate('architecture')}
            className={`flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors hover:text-white cursor-pointer ${
              currentView === 'architecture' ? 'text-cyan-400 font-semibold' : 'text-slate-400'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>Architecture & Spec</span>
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenHealth}
            title="Inspect Django REST API & Subsystem Health"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-slate-700/80 bg-slate-900/90 text-slate-300 hover:text-white hover:border-slate-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span
              className={`h-2 w-2 rounded-full ${
                backendConnected ? 'bg-emerald-400' : 'bg-amber-400'
              }`}
            />
            <span className="hidden sm:inline">API:</span>
            <span className="font-mono text-[11px]">{backendConnected ? 'Healthy v1' : 'Connecting'}</span>
          </button>

          {currentView === 'landing' ? (
            <button
              onClick={() => onNavigate('candidate')}
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm shadow-indigo-600/30 transition-all hover:shadow-indigo-500/40 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Open Candidate Demo
            </button>
          ) : (
            <button
              onClick={() => onNavigate('landing')}
              className="px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white border border-slate-700/80 hover:border-slate-600 bg-slate-900/60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Return to Overview
            </button>
          )}

          {/* Mobile hamburger toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-slate-400 hover:text-white cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-800 bg-slate-950 px-4 pt-2 pb-6 space-y-3">
          <div className="flex flex-col gap-2 pt-2">
            <button
              onClick={() => {
                onNavigate('landing');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 px-3 text-sm font-medium text-slate-300 hover:bg-slate-900 rounded-md"
            >
              Platform Overview
            </button>
            <button
              onClick={() => {
                onNavigate('candidate');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 px-3 text-sm font-medium text-slate-300 hover:bg-slate-900 rounded-md"
            >
              Candidate Workspace
            </button>
            <button
              onClick={() => {
                onNavigate('recruiter');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 px-3 text-sm font-medium text-slate-300 hover:bg-slate-900 rounded-md"
            >
              Recruiter Workspace
            </button>
            <button
              onClick={() => {
                onNavigate('admin');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 px-3 text-sm font-medium text-slate-300 hover:bg-slate-900 rounded-md"
            >
              Admin Hub
            </button>
            <button
              onClick={() => {
                onNavigate('architecture');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 px-3 text-sm font-medium text-cyan-400 hover:bg-slate-900 rounded-md"
            >
              Architecture & OpenAPI Spec
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
