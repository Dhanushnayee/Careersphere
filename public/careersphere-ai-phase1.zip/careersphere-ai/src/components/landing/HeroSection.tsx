/**
 * CareerSphere AI — Hero Section
 * Modern display typography, clean visual preview, honest capability disclosure.
 */
import React from 'react';
import { ArrowRight, Sparkles, CheckCircle2, Shield, Search, FileCheck, Layers } from 'lucide-react';

interface HeroSectionProps {
  onNavigateCandidate: () => void;
  onNavigateRecruiter: () => void;
  onNavigateArchitecture: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onNavigateCandidate,
  onNavigateRecruiter,
  onNavigateArchitecture,
}) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
      {/* Background ambient lighting */}
      <div
        className="pointer-events-none absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80"
        aria-hidden="true"
      >
        <div
          className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-indigo-600/30 via-violet-600/20 to-cyan-500/20 opacity-40 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
        />
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headline and Call-to-actions */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Phase 1 Foundation Editorial Kicker */}
            <div className="text-xs font-medium text-indigo-400 tracking-wide uppercase flex items-center gap-2">
              <span>Phase 1 Project Foundation</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-400 normal-case font-normal">Django REST + PostgreSQL + React 19</span>
            </div>

            {/* Display Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1] [text-wrap:balance]">
              Intelligent Career Discovery and Talent Pipeline Automation.
            </h1>

            {/* Subtitle / Value Proposition */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
              CareerSphere AI connects candidates with verified career opportunities using semantic AI resume matching, while empowering recruiters with structured talent pipelines and compliant application automation.
            </p>

            {/* Primary Action Row */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onNavigateCandidate}
                className="flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-lg shadow-indigo-600/30 transition-all hover:shadow-indigo-500/50 cursor-pointer whitespace-nowrap"
              >
                <span>Launch Candidate Workspace</span>
                <ArrowRight className="h-4 w-4" />
              </button>

              <button
                onClick={onNavigateRecruiter}
                className="flex items-center gap-2 px-5 py-3 text-sm font-medium text-slate-200 hover:text-white border border-slate-700 hover:border-slate-600 bg-slate-900/80 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>Recruiter Portal Preview</span>
              </button>

              <button
                onClick={onNavigateArchitecture}
                className="flex items-center gap-1.5 px-4 py-3 text-xs font-mono text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Layers className="h-3.5 w-3.5" />
                <span>Inspect Backend Specs</span>
              </button>
            </div>

            {/* Architectural Trust Markers */}
            <div className="pt-4 flex flex-wrap items-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>Official Partner ATS Submissions Only</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>Zero-Bypass Candidate Consent Model</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-indigo-400 shrink-0" />
                <span>10MB Private Resume Enclave</span>
              </div>
            </div>
          </div>

          {/* Right Column: Architectural Product Showcase Vector Box */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-2xl backdrop-blur-xl space-y-4">
              
              {/* Card Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-slate-700" />
                  <div className="h-3 w-3 rounded-full bg-slate-700" />
                  <div className="h-3 w-3 rounded-full bg-slate-700" />
                  <span className="ml-2 text-xs font-mono text-slate-400">careersphere.ai/workspace</span>
                </div>
                <span className="text-[11px] font-mono text-indigo-400">Demo Active</span>
              </div>

              {/* Vector Diagnostic Preview */}
              <div className="space-y-3">
                <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-200">AI Resume Diagnostics Preview</span>
                    <span className="font-mono text-indigo-400 font-semibold">Phase 4 Ready</span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-slate-400">
                      <span>ATS Format Compatibility</span>
                      <span className="font-mono text-slate-200 tabular-nums">88%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div className="bg-indigo-500 h-1.5 rounded-full w-[88%]" />
                    </div>
                    <div className="flex items-center justify-between text-slate-400 pt-1">
                      <span>Target Role Alignment</span>
                      <span className="font-mono text-slate-200 tabular-nums">91%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div className="bg-cyan-500 h-1.5 rounded-full w-[91%]" />
                    </div>
                  </div>
                  <div className="pt-1 text-[11px] text-slate-500">
                    Extracted competencies: Python, Django, TypeScript, Docker
                  </div>
                </div>

                {/* Benchmark Job Match Card */}
                <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-slate-100 text-xs">Senior AI Systems Architect</div>
                      <div className="text-[11px] text-slate-400">Synthetix Dynamics · San Francisco (Remote)</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold font-mono text-emerald-400 tabular-nums">94% Match</div>
                      <div className="text-[10px] text-slate-500">Demo Score</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                    <span className="font-mono tabular-nums">$175k - $220k</span>
                    <span className="text-indigo-400">1-Click Guided Submission</span>
                  </div>
                </div>
              </div>

              {/* Status Note */}
              <div className="text-[11px] text-slate-500 text-center pt-1">
                Phase 1 Foundation · Interactive workspaces available for all roles
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
