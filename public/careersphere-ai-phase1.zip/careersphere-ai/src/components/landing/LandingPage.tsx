/**
 * CareerSphere AI — Public Landing Page
 * Cohesive presentation of value proposition, architectural features, and roadmap.
 */
import React from 'react';
import { HeroSection } from './HeroSection';
import { FeatureGrid } from './FeatureGrid';
import { WorkflowSection } from './WorkflowSection';
import { RoleComparison } from './RoleComparison';
import { MilestoneRoadmap } from './MilestoneRoadmap';

interface LandingPageProps {
  onNavigateCandidate: () => void;
  onNavigateRecruiter: () => void;
  onNavigateArchitecture: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigateCandidate,
  onNavigateRecruiter,
  onNavigateArchitecture,
}) => {
  return (
    <div className="space-y-0 text-slate-100">
      <HeroSection
        onNavigateCandidate={onNavigateCandidate}
        onNavigateRecruiter={onNavigateRecruiter}
        onNavigateArchitecture={onNavigateArchitecture}
      />
      <FeatureGrid />
      <WorkflowSection />
      <RoleComparison
        onNavigateCandidate={onNavigateCandidate}
        onNavigateRecruiter={onNavigateRecruiter}
      />
      <MilestoneRoadmap />
    </div>
  );
};
