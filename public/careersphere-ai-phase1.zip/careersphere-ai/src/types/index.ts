/**
 * CareerSphere AI — TypeScript Domain & API Definitions
 * Phase 1 Foundation
 */

export type UserRole = 'candidate' | 'recruiter' | 'admin';

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  meta?: Record<string, unknown>;
  error?: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
}

export interface PlatformHealth {
  platform: string;
  phase: string;
  environment: string;
  timestamp: number;
  dependencies: {
    database: {
      status: 'connected' | 'degraded' | 'unreachable';
      vendor: string;
      note?: string;
    };
    task_queue: {
      status: string;
      broker: string;
      note?: string;
    };
    ai_engine: {
      status: string;
      model: string;
      note?: string;
    };
  };
}

export interface SystemConfig {
  name: string;
  version: string;
  milestone: {
    current: string;
    next: string;
    total_milestones: number;
  };
  supported_roles: Array<{
    id: UserRole;
    label: string;
    active_in_phase: number;
  }>;
  governance: {
    max_resume_upload_mb: number;
    supported_formats: string[];
    security_model: string;
  };
}

export interface BenchmarkJob {
  id: string;
  title: string;
  company_name: string;
  location: string;
  workplace_type: 'Remote' | 'Hybrid' | 'On-site';
  employment_type: 'Full-time' | 'Contract' | 'Part-time';
  salary_range: string;
  skills_required: string[];
  match_score_demo: number;
  applicants_count: number;
  posted_days_ago: number;
  description: string;
}

export interface AuditRecord {
  id: string;
  action: string;
  resource_type: string;
  actor: string;
  ip_address: string;
  timestamp_seconds_ago: number;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
  summary: string;
}

export interface CandidateResume {
  id: string;
  title: string;
  fileName: string;
  fileSizeBytes: number;
  fileFormat: string;
  uploadedAt: string;
  isPrimary: boolean;
  parsingStatus: 'parsed' | 'pending' | 'processing';
  atsScoreDemo: number;
}

export interface ApplicationActivity {
  id: string;
  jobTitle: string;
  companyName: string;
  appliedDate: string;
  status: 'Submitted' | 'Under Review' | 'Interview Scheduled' | 'Offer Received';
  matchScore: number;
  portal: string;
}
