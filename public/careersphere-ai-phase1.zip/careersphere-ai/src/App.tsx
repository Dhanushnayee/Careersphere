/**
 * CareerSphere AI — Main Application Controller
 * Phase 1 Foundation & Initial Implementation
 */
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { LandingPage } from './components/landing/LandingPage';
import { CandidateDashboard } from './components/dashboards/CandidateDashboard';
import { RecruiterDashboard } from './components/dashboards/RecruiterDashboard';
import { AdminDashboard } from './components/dashboards/AdminDashboard';
import { ArchitectureExplorer } from './components/architecture/ArchitectureExplorer';
import { HealthModal } from './components/common/HealthModal';
import { ResumeUploadModal } from './components/common/ResumeUploadModal';
import { PlatformHealth, BenchmarkJob, AuditRecord, CandidateResume } from './types';
import { apiClient } from './services/api';
import { Sparkles, User, Briefcase, Shield, Layers } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'candidate' | 'recruiter' | 'admin' | 'architecture'>('landing');
  const [health, setHealth] = useState<PlatformHealth | null>(null);
  const [backendConnected, setBackendConnected] = useState(false);
  const [healthModalOpen, setHealthModalOpen] = useState(false);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [jobs, setJobs] = useState<BenchmarkJob[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditRecord[]>([]);
  const [resumes, setResumes] = useState<CandidateResume[]>([
    {
      id: 'res_01',
      title: 'Alex_Chen_Principal_Engineer_Resume.pdf',
      fileName: 'Alex_Chen_Principal_Engineer_Resume.pdf',
      fileSizeBytes: 248000,
      fileFormat: 'PDF',
      uploadedAt: '2 days ago',
      isPrimary: true,
      parsingStatus: 'parsed',
      atsScoreDemo: 88,
    },
  ]);

  useEffect(() => {
    // Probe backend health and load initial benchmark data
    async function init() {
      try {
        const healthData = await apiClient.getHealth();
        setHealth(healthData);
        setBackendConnected(healthData.dependencies.database.status !== 'unreachable');

        const [jobsData, logsData] = await Promise.all([
          apiClient.getSampleJobs(),
          apiClient.getAuditLogs(),
        ]);
        setJobs(jobsData);
        setAuditLogs(logsData);
      } catch (err) {
        console.warn('Initial platform probe error:', err);
      }
    }
    init();
  }, []);

  const handleAddJob = (newJob: BenchmarkJob) => {
    setJobs((prev) => [newJob, ...prev]);
  };

  const handleResumeUploaded = (newResume: CandidateResume) => {
    setResumes((prev) => [newResume, ...prev]);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Bar Navigation */}
      <Navbar
        currentView={currentView}
        onNavigate={setCurrentView}
        onOpenHealth={() => setHealthModalOpen(true)}
        backendConnected={backendConnected}
      />

      {/* Role Workspace Context Switcher (Shown when inside any dashboard) */}
      {currentView !== 'landing' && (
        <div className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-sm px-4 sm:px-6 lg:px-8 py-2.5">
          <div className="mx-auto max-w-7xl flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-slate-400">
              <span className="font-semibold text-slate-200 uppercase tracking-wider text-[11px]">Workspace Mode:</span>
              <span className="text-indigo-400 font-medium capitalize">{currentView}</span>
            </div>

            <div className="flex items-center gap-1.5 p-1 rounded-lg bg-slate-950/80 border border-slate-800">
              <button
                onClick={() => setCurrentView('candidate')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors cursor-pointer ${
                  currentView === 'candidate'
                    ? 'bg-indigo-600 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <User className="h-3.5 w-3.5" />
                <span>Candidate</span>
              </button>

              <button
                onClick={() => setCurrentView('recruiter')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors cursor-pointer ${
                  currentView === 'recruiter'
                    ? 'bg-indigo-600 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Briefcase className="h-3.5 w-3.5" />
                <span>Recruiter</span>
              </button>

              <button
                onClick={() => setCurrentView('admin')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors cursor-pointer ${
                  currentView === 'admin'
                    ? 'bg-indigo-600 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Shield className="h-3.5 w-3.5" />
                <span>Admin Hub</span>
              </button>

              <button
                onClick={() => setCurrentView('architecture')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors cursor-pointer ${
                  currentView === 'architecture'
                    ? 'bg-cyan-600 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Layers className="h-3.5 w-3.5" />
                <span>Architecture</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Viewport */}
      <main className="flex-1">
        {currentView === 'landing' && (
          <LandingPage
            onNavigateCandidate={() => setCurrentView('candidate')}
            onNavigateRecruiter={() => setCurrentView('recruiter')}
            onNavigateArchitecture={() => setCurrentView('architecture')}
          />
        )}

        {currentView === 'candidate' && (
          <CandidateDashboard
            jobs={jobs}
            resumes={resumes}
            onOpenUploadModal={() => setUploadModalOpen(true)}
          />
        )}

        {currentView === 'recruiter' && (
          <RecruiterDashboard
            jobs={jobs}
            onAddJob={handleAddJob}
          />
        )}

        {currentView === 'admin' && (
          <AdminDashboard
            auditLogs={auditLogs}
            health={health}
            onOpenHealth={() => setHealthModalOpen(true)}
          />
        )}

        {currentView === 'architecture' && <ArchitectureExplorer />}
      </main>

      {/* Global Footer */}
      <Footer
        onNavigate={setCurrentView}
        onOpenHealth={() => setHealthModalOpen(true)}
      />

      {/* Backend Health Diagnostics Modal */}
      <HealthModal
        isOpen={healthModalOpen}
        onClose={() => setHealthModalOpen(false)}
        initialHealth={health}
        onHealthUpdate={setHealth}
      />

      {/* Resume Document Upload Modal */}
      <ResumeUploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onUploadSuccess={handleResumeUploaded}
      />
    </div>
  );
}
