"""
CareerSphere AI — Accounts Serializers
Phase 1 Foundation
"""
from rest_framework import serializers
from apps.accounts.models import User


class UserPublicSerializer(serializers.ModelSerializer):
    """Safe read-only serializer for user profile previews."""
    role_display = serializers.CharField(source="get_role_display", read_only=True)

    class Meta:
        model = User
        fields = [
            "uuid",
            "email",
            "username",
            "first_name",
            "last_name",
            "role",
            "role_display",
            "is_email_verified",
            "created_at",
        ]
        read_only_fields = fields
