from django.urls import path
from apps.accounts.views import AuthStatusView

urlpatterns = [
    path("auth/status/", AuthStatusView.as_view(), name="auth-status"),
]
