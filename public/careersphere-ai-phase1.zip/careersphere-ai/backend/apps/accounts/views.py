"""
CareerSphere AI — Accounts Views
Phase 1 Foundation
"""
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from drf_spectacular.utils import extend_schema
from apps.common.responses import success_response


class AuthStatusView(APIView):
    """
    Reports authentication module status.
    Phase 2 will implement secure registration, email OTP, and JWT authentication.
    """
    permission_classes = [AllowAny]

    @extend_schema(summary="Authentication System Architecture Status")
    def get(self, request):
        return success_response(
            data={
                "status": "ready_for_phase2",
                "auth_strategy": "Argon2/PBKDF2 + HTTP-only JWT + Email OTP",
                "roles_configured": ["candidate", "recruiter", "admin"],
                "note": "Production authentication endpoints will be activated in Phase 2 milestone.",
            },
            message="Accounts subsystem architecture verified.",
        )
