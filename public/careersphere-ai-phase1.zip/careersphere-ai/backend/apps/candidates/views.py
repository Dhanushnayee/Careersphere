"""
CareerSphere AI — Candidate Views
Phase 1 Foundation
"""
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from drf_spectacular.utils import extend_schema
from apps.common.responses import success_response


class CandidateBenchmarkView(APIView):
    """
    Returns baseline demonstration data and schema benchmarks for Candidate workspace.
    """
    permission_classes = [AllowAny]

    @extend_schema(summary="Candidate Workspace Baseline Schema")
    def get(self, request):
        return success_response(
            data={
                "workspace": "candidate",
                "phase": "Phase 1 Foundation",
                "features_active": [
                    "Resume document storage schema",
                    "Skills inventory architecture",
                    "AI copilot payload definitions",
                    "Application tracking data model",
                ],
            },
            message="Candidate workspace architecture ready.",
        )
