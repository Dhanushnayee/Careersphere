from django.urls import path
from apps.candidates.views import CandidateBenchmarkView

urlpatterns = [
    path("candidates/benchmark/", CandidateBenchmarkView.as_view(), name="candidate-benchmark"),
]
