"""
Applications Subsystem
"""
