"""
Notifications Application
"""
