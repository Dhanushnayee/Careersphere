"""
CareerSphere AI Settings Package
"""
