# CareerSphere AI — Phase 1 Project Foundation

> **AI-Powered Full-Stack Job Application Platform & Career Copilot**  
> **Phase 1 Milestone:** Complete Project Foundation, Django Modular Backend, React UI, and Docker Architecture.

---

## 1. Project Overview

CareerSphere AI is designed to empower candidates and students to discover suitable career opportunities, optimize their resumes with intelligent AI analysis, and submit compliant applications. The platform concurrently delivers dedicated workspaces for HR recruiters to publish positions and evaluate candidate talent pipelines, as well as an administrative governance center.

Phase 1 establishes a rock-solid, production-grade foundation across both backend and frontend layers to enable seamless expansion through all subsequent milestones without requiring architectural refactoring.

---

## 2. Seven-Milestone Development Roadmap

1. **Phase 1: Project Foundation & Initial Implementation** *(Current Phase - Fully Complete)*
   - Monorepo directory structure (`frontend/`, `backend/`, `docs/`, `docker-compose.yml`)
   - 10 modular Django applications (`accounts`, `candidates`, `recruiters`, `jobs`, `applications`, `resumes`, `ai_copilot`, `automation`, `notifications`, `audit`)
   - PostgreSQL & Redis configuration, Celery worker integration points, Docker Compose
   - Standardized API response envelopes, centralized exception handling, versioned `/api/v1/` routes
   - Polished SaaS React UI in Navy/Violet/Cyan design system:
     - Public Landing Page
     - Candidate Workspace (Resume upload & AI Copilot preview)
     - Recruiter Workspace (Pipeline metrics, job postings)
     - Administrator Hub (Health diagnostics, audit trail)
     - Interactive Architecture & OpenAPI Explorer
   - Unit test suite, automated syntax verification, and ZIP release packaging.

2. **Phase 2: Authentication & Role-Based Access Control** *(Next Milestone)*
   - Email OTP verification, JWT token sessions, candidate/recruiter/admin permission guards.

3. **Phase 3: Jobs & Applications Lifecycle Management**
   - Full CRUD job requisition portal, faceted search, candidate application tracking.

4. **Phase 4: AI Resume Analysis & Resume Copilot**
   - Full PDF/DOCX parsing, Google Gemini LLM scoring, keyword extraction, bullet rewrites.

5. **Phase 5: Job Application Automation & Safe Orchestration**
   - Official partner ATS API submissions (Greenhouse, Lever), consent enforcement, idempotency, and safe manual handoffs.

6. **Phase 6: Administration, Quality Assurance & Security Audit**
   - Moderation consoles, rate limiting, vulnerability scanning, end-to-end tests.

7. **Phase 7: Production Deployment & Release Packaging**
   - Cloud Run / Kubernetes deployment, CDN edge caching, final ZIP archive delivery.

---

## 3. Monorepo Structure

```
careersphere-ai/
├── .env.example                  # Comprehensive environment variables template
├── .dockerignore                 # Docker build ignore rules
├── .gitignore                    # Git version control exclusions
├── docker-compose.yml            # Multi-container orchestration (DB, Redis, Backend, Frontend)
├── README.md                     # Complete developer and setup guide
├── package.json                  # Node.js dependencies and scripts
├── vite.config.ts                # Vite configuration with Tailwind CSS
├── tsconfig.json                 # TypeScript compiler configuration
├── server.ts                     # Full-stack API & dev proxy server
│
├── docs/
│   ├── ARCHITECTURE.md           # System architecture blueprint & entity diagrams
│   └── API_SPEC.md               # OpenAPI specification for /api/v1/ routes
│
├── backend/                      # Python Django REST Framework Service
│   ├── Dockerfile                # Backend container image definition
│   ├── manage.py                 # Django management CLI
│   ├── requirements.txt          # Pinned Python package dependencies
│   ├── careersphere_ai/          # Core Django project configuration
│   │   ├── settings/
│   │   │   ├── base.py           # Shared settings, apps, logging, upload limits
│   │   │   ├── development.py    # Local settings (SQLite/PostgreSQL fallback, debug)
│   │   │   └── production.py     # Production settings (SSL, HSTS, secrets enforcement)
│   │   ├── asgi.py               # Asynchronous server entry point
│   │   ├── wsgi.py               # WSGI server entry point
│   │   ├── celery.py             # Celery distributed task queue configuration
│   │   └── urls.py               # Root URL router & OpenAPI documentation
│   ├── apps/
│   │   ├── common/               # Response envelopes, exception handler, health views
│   │   ├── accounts/             # Custom User model, UserRole enum
│   │   ├── candidates/           # CandidateProfile model, skills, target role
│   │   ├── recruiters/           # Company, RecruiterProfile models
│   │   ├── jobs/                 # JobListing, workplace & employment types
│   │   ├── applications/         # JobApplication tracking model
│   │   ├── resumes/              # ResumeDocument storage and 10MB upload limits
│   │   ├── ai_copilot/           # ResumeAnalysisResult model & schema contract
│   │   ├── automation/           # AutomationTask, consent rules, idempotency
│   │   ├── notifications/        # NotificationEvent model
│   │   └── audit/                # Immutable AuditLog model
│   └── tests/
│       ├── runner.py             # Autonomous test runner & Python syntax auditor
│       ├── test_health.py        # Health probe tests
│       ├── test_settings_security.py # Security header and settings tests
│       ├── test_models.py        # Domain model integrity tests
│       └── test_api_responses.py # API envelope contract tests
│
└── src/                          # Modern React 19 Frontend Client
    ├── main.tsx                  # React DOM mount point
    ├── App.tsx                   # App controller, role switcher, route coordinator
    ├── index.css                 # Tailwind CSS 4 setup & typography
    ├── types/                    # TypeScript interfaces for API & Domain models
    ├── services/                 # Typed API client with fallback resilience
    └── components/
        ├── common/               # Top bar, footer, buttons, cards, modals
        ├── landing/              # Hero, features, workflow, milestone tracker
        ├── dashboards/           # Candidate, Recruiter, and Admin dashboards
        └── architecture/         # Interactive system & schema inspector
```

---

## 4. Quickstart Guide

### Prerequisites
- **Python**: 3.10, 3.11, or 3.12
- **Node.js**: 18.x or 20.x+
- **Docker & Docker Compose** (optional for containerized run)
- **PostgreSQL 16+** & **Redis 7+** (or use Docker Compose)

---

### Option A: Local Development Setup (Manual)

#### 1. Configure Environment
Copy the `.env.example` template to `.env`:

**Windows (PowerShell):**
```powershell
Copy-Item .env.example .env
```

**Linux / macOS (Bash):**
```bash
cp .env.example .env
```

#### 2. Backend Setup (Django)

**Windows (PowerShell):**
```powershell
cd backend
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
```

**Linux / macOS (Bash):**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
```

#### 3. Frontend Setup (React & Vite)
In a separate terminal:

**Windows & Linux/macOS:**
```bash
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your web browser.

---

### Option B: Docker Compose Setup (One-Command Launch)

To start the full stack including PostgreSQL, Redis, Django, Celery Worker, and React:

```bash
docker-compose up --build
```

Services launched:
- **Frontend**: [http://localhost:3000](http://localhost:3000)
- **Backend API**: [http://localhost:8000/api/v1/](http://localhost:8000/api/v1/)
- **API Documentation**: [http://localhost:8000/api/docs/](http://localhost:8000/api/docs/)
- **PostgreSQL**: `localhost:5432`
- **Redis**: `localhost:6379`

To stop services:
```bash
docker-compose down
```

---

## 5. Verification & Automated Testing

### 1. Run Backend Tests & Syntax Audit
Run the autonomous Python test suite:
```bash
python3 backend/tests/runner.py
```
*Executes all 17 unit tests and audits all 82 Python files for syntax errors.*

### 2. Run Frontend Checks & Production Build
```bash
npm run lint     # TypeScript type-checking
npm run build    # Production asset compilation
```

---

## 6. Troubleshooting

- **Database Connection Refused**:
  - In local development without PostgreSQL, the development settings automatically fall back to SQLite (`dev_careersphere.sqlite3`).
  - To connect to PostgreSQL, ensure Docker is running `docker-compose up postgres` or update `DB_HOST` in `.env`.
- **Port 3000 or 8000 in use**:
  - Check active processes:
    - On Linux/macOS: `lsof -i :3000` or `lsof -i :8000`
    - On Windows: `netstat -ano | findstr :3000`
- **CORS Errors**:
  - Verify that `CORS_ALLOWED_ORIGINS` in `.env` includes your frontend origin (e.g., `http://localhost:3000`).

---

## 7. License & Credits

Built as part of CareerSphere AI Platform Architecture.  
All code licensed under the Apache 2.0 License.
